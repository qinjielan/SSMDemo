prompt PL/SQL Developer import file
prompt Created on 2019��9��11�� by qinjielan
set feedback off
set define off
prompt Disabling triggers for PRODUCT...
alter table PRODUCT disable all triggers;
prompt Disabling triggers for ORDERS...
alter table ORDERS disable all triggers;
prompt Disabling triggers for SYS_LOG...
alter table SYS_LOG disable all triggers;
prompt Disabling triggers for SYS_PERMISSION...
alter table SYS_PERMISSION disable all triggers;
prompt Disabling triggers for SYS_ROLE...
alter table SYS_ROLE disable all triggers;
prompt Disabling triggers for SYS_ROLE_PERMISSION...
alter table SYS_ROLE_PERMISSION disable all triggers;
prompt Disabling triggers for SYS_USER...
alter table SYS_USER disable all triggers;
prompt Disabling triggers for SYS_USER_ROLE...
alter table SYS_USER_ROLE disable all triggers;
prompt Disabling foreign key constraints for ORDERS...
alter table ORDERS disable constraint SYS_C005472;
prompt Disabling foreign key constraints for SYS_ROLE_PERMISSION...
alter table SYS_ROLE_PERMISSION disable constraint SYS_C005481;
alter table SYS_ROLE_PERMISSION disable constraint SYS_C005482;
prompt Disabling foreign key constraints for SYS_USER_ROLE...
alter table SYS_USER_ROLE disable constraint SYS_C005478;
alter table SYS_USER_ROLE disable constraint SYS_C005479;
prompt Deleting SYS_USER_ROLE...
delete from SYS_USER_ROLE;
commit;
prompt Deleting SYS_USER...
delete from SYS_USER;
commit;
prompt Deleting SYS_ROLE_PERMISSION...
delete from SYS_ROLE_PERMISSION;
commit;
prompt Deleting SYS_ROLE...
delete from SYS_ROLE;
commit;
prompt Deleting SYS_PERMISSION...
delete from SYS_PERMISSION;
commit;
prompt Deleting SYS_LOG...
delete from SYS_LOG;
commit;
prompt Deleting ORDERS...
delete from ORDERS;
commit;
prompt Deleting PRODUCT...
delete from PRODUCT;
commit;
prompt Loading PRODUCT...
insert into PRODUCT (id, productnum, productname, cityname, departuretime, productprice, productdesc, productstatus)
values (1, 'a001', '��������7����', '����', to_timestamp('01-10-2019 08:40:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 19999, '��1', 0);
insert into PRODUCT (id, productnum, productname, cityname, departuretime, productprice, productdesc, productstatus)
values (2, 'a002', '����3����', '����', to_timestamp('19-09-2019 14:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 2000, '1111', 1);
insert into PRODUCT (id, productnum, productname, cityname, departuretime, productprice, productdesc, productstatus)
values (9, '11111', '111', '����', to_timestamp('07-09-2019 19:52:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 1, null, 0);
insert into PRODUCT (id, productnum, productname, cityname, departuretime, productprice, productdesc, productstatus)
values (11, '111113', '123123', '����', to_timestamp('07-09-2019 19:53:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 123, null, 0);
insert into PRODUCT (id, productnum, productname, cityname, departuretime, productprice, productdesc, productstatus)
values (13, '111123', '��������7����1', '����', to_timestamp('07-09-2019 19:55:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 1, null, 0);
insert into PRODUCT (id, productnum, productname, cityname, departuretime, productprice, productdesc, productstatus)
values (10, '11112', '11112', '����', to_timestamp('07-09-2019 19:52:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 111, null, 0);
insert into PRODUCT (id, productnum, productname, cityname, departuretime, productprice, productdesc, productstatus)
values (14, '11223', '123123', '����', to_timestamp('07-09-2019 20:10:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 1, null, 0);
commit;
prompt 7 records loaded
prompt Loading ORDERS...
insert into ORDERS (id, ordernum, ordertime, peoplecount, orderdesc, paytype, orderstatus, productid)
values (1, '123', to_timestamp('07-09-2019 16:31:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 123, '123' || chr(9) || '' || chr(9) || '', 1, 1, 1);
insert into ORDERS (id, ordernum, ordertime, peoplecount, orderdesc, paytype, orderstatus, productid)
values (3, '1234', to_timestamp('07-09-2019 16:31:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 123, '123' || chr(9) || '' || chr(9) || '', 1, 1, 1);
insert into ORDERS (id, ordernum, ordertime, peoplecount, orderdesc, paytype, orderstatus, productid)
values (4, '111', to_timestamp('07-09-2019 16:33:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 123, '' || chr(9) || '' || chr(9) || '' || chr(9) || '' || chr(9) || '' || chr(9) || '' || chr(9) || '', 0, 1, 1);
commit;
prompt 3 records loaded
prompt Loading SYS_LOG...
insert into SYS_LOG (id, visittime, username, ip, method)
values (1, to_timestamp('10-09-2019 16:59:55.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'admin', '0:0:0:0:0:0:0:1', 'com.qjl.controller.UserController.findAll');
insert into SYS_LOG (id, visittime, username, ip, method)
values (2, to_timestamp('10-09-2019 17:00:34.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'admin', '0:0:0:0:0:0:0:1', 'com.qjl.controller.UserController.details');
insert into SYS_LOG (id, visittime, username, ip, method)
values (3, to_timestamp('10-09-2019 17:15:45.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'admin', '0:0:0:0:0:0:0:1', 'com.qjl.controller.LogController.findAllToLog');
insert into SYS_LOG (id, visittime, username, ip, method)
values (4, to_timestamp('10-09-2019 17:16:04.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'admin', '0:0:0:0:0:0:0:1', 'com.qjl.controller.RoleController.findAll');
insert into SYS_LOG (id, visittime, username, ip, method)
values (5, to_timestamp('10-09-2019 17:16:07.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'admin', '0:0:0:0:0:0:0:1', 'com.qjl.controller.LogController.findAllToLog');
insert into SYS_LOG (id, visittime, username, ip, method)
values (6, to_timestamp('10-09-2019 17:18:23.275000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'admin', '0:0:0:0:0:0:0:1', 'com.qjl.controller.LogController.findAllToLog');
insert into SYS_LOG (id, visittime, username, ip, method)
values (7, to_timestamp('10-09-2019 17:19:02.740000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'admin', '0:0:0:0:0:0:0:1', 'com.qjl.controller.LogController.findAllToLog');
commit;
prompt 7 records loaded
prompt Loading SYS_PERMISSION...
insert into SYS_PERMISSION (id, permissionname, url, pid)
values (7, '11', '11', 1);
insert into SYS_PERMISSION (id, permissionname, url, pid)
values (1, 'ϵͳ����', null, 0);
insert into SYS_PERMISSION (id, permissionname, url, pid)
values (2, '��������', null, 0);
insert into SYS_PERMISSION (id, permissionname, url, pid)
values (3, '�û�ģ��', '/user/findAll', 1);
insert into SYS_PERMISSION (id, permissionname, url, pid)
values (4, '��ɫģ��', '/role/findAll', 1);
insert into SYS_PERMISSION (id, permissionname, url, pid)
values (5, '��Ʒ����', '/product/findAll', 2);
commit;
prompt 6 records loaded
prompt Loading SYS_ROLE...
insert into SYS_ROLE (id, rolename, roledesc)
values (2, 'user', '123');
insert into SYS_ROLE (id, rolename, roledesc)
values (3, 'user1', '123');
insert into SYS_ROLE (id, rolename, roledesc)
values (4, '123', '123');
insert into SYS_ROLE (id, rolename, roledesc)
values (1, 'ADMIN', '����Ա');
insert into SYS_ROLE (id, rolename, roledesc)
values (5, 'USER', '�û�');
commit;
prompt 5 records loaded
prompt Loading SYS_ROLE_PERMISSION...
insert into SYS_ROLE_PERMISSION (permissionid, roleid)
values (1, 1);
insert into SYS_ROLE_PERMISSION (permissionid, roleid)
values (2, 1);
insert into SYS_ROLE_PERMISSION (permissionid, roleid)
values (3, 1);
insert into SYS_ROLE_PERMISSION (permissionid, roleid)
values (4, 1);
insert into SYS_ROLE_PERMISSION (permissionid, roleid)
values (5, 1);
insert into SYS_ROLE_PERMISSION (permissionid, roleid)
values (5, 2);
commit;
prompt 6 records loaded
prompt Loading SYS_USER...
insert into SYS_USER (id, username, email, password, phonenum, status)
values (21, 'qinjielan', 'admin@qq.com', '$2a$10$R5OcTm.7G90pXFW5I/2m4e.4dEomf4dn8aiyPd9WsTZ4LYMDJwoJ2', '11111111111', 1);
insert into SYS_USER (id, username, email, password, phonenum, status)
values (1, 'zhangsan', 'zhangsan@qq.com', '123', '13188888888', 1);
insert into SYS_USER (id, username, email, password, phonenum, status)
values (2, 'lisi', 'lisi@qq.com', '123', '13188888889', 1);
insert into SYS_USER (id, username, email, password, phonenum, status)
values (8, '123', 'admin@qq.com', '123', '123', 0);
insert into SYS_USER (id, username, email, password, phonenum, status)
values (12, 'admin', 'admin@qq.com', '$2a$10$XwLfT.8ay8owQ5pPWpWmVulM9QcFpnI4edsqc17YFbidKD9f7LuFe', '123', 1);
commit;
prompt 5 records loaded
prompt Loading SYS_USER_ROLE...
insert into SYS_USER_ROLE (userid, roleid)
values (12, 1);
insert into SYS_USER_ROLE (userid, roleid)
values (12, 2);
insert into SYS_USER_ROLE (userid, roleid)
values (12, 3);
insert into SYS_USER_ROLE (userid, roleid)
values (12, 4);
insert into SYS_USER_ROLE (userid, roleid)
values (21, 5);
commit;
prompt 5 records loaded
prompt Enabling foreign key constraints for ORDERS...
alter table ORDERS enable constraint SYS_C005472;
prompt Enabling foreign key constraints for SYS_ROLE_PERMISSION...
alter table SYS_ROLE_PERMISSION enable constraint SYS_C005481;
alter table SYS_ROLE_PERMISSION enable constraint SYS_C005482;
prompt Enabling foreign key constraints for SYS_USER_ROLE...
alter table SYS_USER_ROLE enable constraint SYS_C005478;
alter table SYS_USER_ROLE enable constraint SYS_C005479;
prompt Enabling triggers for PRODUCT...
alter table PRODUCT enable all triggers;
prompt Enabling triggers for ORDERS...
alter table ORDERS enable all triggers;
prompt Enabling triggers for SYS_LOG...
alter table SYS_LOG enable all triggers;
prompt Enabling triggers for SYS_PERMISSION...
alter table SYS_PERMISSION enable all triggers;
prompt Enabling triggers for SYS_ROLE...
alter table SYS_ROLE enable all triggers;
prompt Enabling triggers for SYS_ROLE_PERMISSION...
alter table SYS_ROLE_PERMISSION enable all triggers;
prompt Enabling triggers for SYS_USER...
alter table SYS_USER enable all triggers;
prompt Enabling triggers for SYS_USER_ROLE...
alter table SYS_USER_ROLE enable all triggers;
set feedback on
set define on
prompt Done.
