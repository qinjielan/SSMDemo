-------------------------------------------------
-- Export file for user QJL                    --
-- Created by qinjielan on 2019/9/11, 16:47:05 --
-------------------------------------------------

set define off
spool ssm.log

prompt
prompt Creating table PRODUCT
prompt ======================
prompt
create table QJL.PRODUCT
(
  id            NUMBER not null,
  productnum    VARCHAR2(50) not null,
  productname   VARCHAR2(50),
  cityname      VARCHAR2(50),
  departuretime TIMESTAMP(6),
  productprice  NUMBER(8,2),
  productdesc   VARCHAR2(500),
  productstatus INTEGER
)
tablespace SSM
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table QJL.PRODUCT
  add primary key (ID)
  using index 
  tablespace SSM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table QJL.PRODUCT
  add unique (PRODUCTNUM)
  using index 
  tablespace SSM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table ORDERS
prompt =====================
prompt
create table QJL.ORDERS
(
  id          NUMBER not null,
  ordernum    VARCHAR2(20) not null,
  ordertime   TIMESTAMP(6),
  peoplecount NUMBER,
  orderdesc   VARCHAR2(500),
  paytype     NUMBER,
  orderstatus NUMBER,
  productid   INTEGER
)
tablespace SSM
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table QJL.ORDERS
  add primary key (ID)
  using index 
  tablespace SSM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table QJL.ORDERS
  add unique (ORDERNUM)
  using index 
  tablespace SSM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table QJL.ORDERS
  add foreign key (PRODUCTID)
  references QJL.PRODUCT (ID);

prompt
prompt Creating table SYS_LOG
prompt ======================
prompt
create table QJL.SYS_LOG
(
  id        NUMBER not null,
  visittime TIMESTAMP(6),
  username  VARCHAR2(50),
  ip        VARCHAR2(30),
  method    VARCHAR2(200)
)
tablespace SSM
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table QJL.SYS_LOG
  add primary key (ID)
  using index 
  tablespace SSM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table SYS_PERMISSION
prompt =============================
prompt
create table QJL.SYS_PERMISSION
(
  id             NUMBER not null,
  permissionname VARCHAR2(50),
  url            VARCHAR2(50),
  pid            NUMBER
)
tablespace SSM
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table QJL.SYS_PERMISSION
  add primary key (ID)
  using index 
  tablespace SSM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table SYS_ROLE
prompt =======================
prompt
create table QJL.SYS_ROLE
(
  id       NUMBER not null,
  rolename VARCHAR2(50),
  roledesc VARCHAR2(50)
)
tablespace SSM
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table QJL.SYS_ROLE
  add primary key (ID)
  using index 
  tablespace SSM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table SYS_ROLE_PERMISSION
prompt ==================================
prompt
create table QJL.SYS_ROLE_PERMISSION
(
  permissionid NUMBER not null,
  roleid       NUMBER not null
)
tablespace SSM
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table QJL.SYS_ROLE_PERMISSION
  add primary key (PERMISSIONID, ROLEID)
  using index 
  tablespace SSM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table QJL.SYS_ROLE_PERMISSION
  add foreign key (PERMISSIONID)
  references QJL.SYS_PERMISSION (ID);
alter table QJL.SYS_ROLE_PERMISSION
  add foreign key (ROLEID)
  references QJL.SYS_ROLE (ID);

prompt
prompt Creating table SYS_USER
prompt =======================
prompt
create table QJL.SYS_USER
(
  id       NUMBER not null,
  username VARCHAR2(50),
  email    VARCHAR2(50),
  password VARCHAR2(80),
  phonenum VARCHAR2(20),
  status   NUMBER
)
tablespace SSM
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table QJL.SYS_USER
  add primary key (ID)
  using index 
  tablespace SSM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table QJL.SYS_USER
  add unique (USERNAME)
  using index 
  tablespace SSM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );

prompt
prompt Creating table SYS_USER_ROLE
prompt ============================
prompt
create table QJL.SYS_USER_ROLE
(
  userid NUMBER not null,
  roleid NUMBER not null
)
tablespace SSM
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table QJL.SYS_USER_ROLE
  add primary key (USERID, ROLEID)
  using index 
  tablespace SSM
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table QJL.SYS_USER_ROLE
  add foreign key (USERID)
  references QJL.SYS_USER (ID);
alter table QJL.SYS_USER_ROLE
  add foreign key (ROLEID)
  references QJL.SYS_ROLE (ID);

prompt
prompt Creating sequence LOG_SEQ
prompt =========================
prompt
create sequence QJL.LOG_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence ORDER_SEQ
prompt ===========================
prompt
create sequence QJL.ORDER_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence PERMISSION_SEQ
prompt ================================
prompt
create sequence QJL.PERMISSION_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence PRODUCT_SEQ
prompt =============================
prompt
create sequence QJL.PRODUCT_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence ROLE_SEQ
prompt ==========================
prompt
create sequence QJL.ROLE_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 21
increment by 1
cache 20;

prompt
prompt Creating sequence USER_SEQ
prompt ==========================
prompt
create sequence QJL.USER_SEQ
minvalue 1
maxvalue 999999999999999999999999999
start with 41
increment by 1
cache 20;


spool off
